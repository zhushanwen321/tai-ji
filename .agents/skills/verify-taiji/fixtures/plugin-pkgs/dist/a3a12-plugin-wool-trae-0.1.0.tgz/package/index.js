export { activate } from "./src/index.ts";
