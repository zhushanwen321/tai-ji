// verify-taiji A23a fixture（S23 双产物·pi 扩展侧）：本剧本只断言安装落盘与卸载清理，
// 不进入会话加载链；入口保持可加载的最小形态。
export default {}
