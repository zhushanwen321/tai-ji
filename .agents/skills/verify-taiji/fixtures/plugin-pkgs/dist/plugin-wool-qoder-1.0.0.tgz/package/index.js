// verify-taiji A23a fixture（S23 双产物·插件侧）：激活即 providers.write 授权落盘 +
// 授权挂载位推哨兵树。零 import（sandbox 黑名单防线内），动作全经 ctx.api RPC。
const AUTHORIZE_MOUNT = 'provider.authorize'
const AUTHORIZED_SENTINEL = 'A23A-AUTHORIZED-SENTINEL-7Q'

export async function activate(context) {
  const api = context.api
  // 授权完成动作（真实羊毛家族 = OAuth 后插件上报凭据；fixture 直写等价落盘态，
  // 命名空间边界由宿主 providers.write 代理复核：providerId 必须落在 wool-qoder* 前缀内）
  await api.providers.write({
    providerId: 'wool-qoder',
    apiKey: 'A23A-FIXTURE-KEY-7Q',
    displayName: 'Qoder (verify fixture)',
    models: [
      { id: 'qoder-model-1', name: 'qoder-model-1' },
      { id: 'qoder-model-2', name: 'qoder-model-2' },
    ],
  })
  await api.views.update(
    AUTHORIZE_MOUNT,
    [{ type: 'ansi-text', props: { lines: [`${AUTHORIZED_SENTINEL} · wool-qoder 授权完成（providers.write 已执行）`] } }],
    { mountId: AUTHORIZE_MOUNT },
  )
  await api.commands.register({ id: 'getStatus' }, () => null)
}

export async function deactivate() {}
export function isActivated() { return true }
